import bpy
import bpy_extras.object_utils
import mathutils
import numpy as np
from ..cAPI import SimulationAPI

def create(curve_obj, operator = None):
    if (curve_obj.type != 'CURVES'):
        if operator:
            operator.report({"ERROR"}, "Binding mesh " + curve_obj.name + " is not a curves object")
        return False;
    n_curves = len(curve_obj.data.curves)
    n_points = curve_obj.data.attributes.domain_size('POINT')
    points = np.zeros((n_points, 3), dtype=np.float32)
    curve_obj.data.attributes['position'].data.foreach_get('vector', np.ravel(points))
    parameterization = np.zeros(n_points, dtype=np.float32)
    for c in range(n_curves):
        offset = curve_obj.data.curve_offset_data[c].value
        next_offset = curve_obj.data.curve_offset_data[c + 1].value
        vert_counts = next_offset - offset;
        l = 0
        parameterization[offset] = 0;
        for v in range(vert_counts - 1):
            l = l + np.linalg.norm(points[offset + v + 1] - points[offset + v])
            parameterization[offset + v + 1] = l
        for v in range(vert_counts):
            parameterization[offset + v] = parameterization[offset + v] / l 

    attr_name = "hi_phy_parameterization";
    if attr_name in curve_obj.data.attributes:
        parameterization_attr = curve_obj.data.attributes[attr_name];
    else:
        parameterization_attr = curve_obj.data.attributes.new(attr_name, 'FLOAT', 'POINT')
    parameterization_attr.data.foreach_set('value', parameterization);
    return True
