import SimulationAPI

#create scene
scene = SimulationAPI.Scene("TestScene")
solver = scene.GetSolver();
cube = scene.CreateNode("cube", SimulationAPI.Node.Type.Geometry);

material_attribute = cube.CreateAttribute("material");
material_attribute.SetEnumValue(SimulationAPI.SimulationObjectType.AffineBody);

num_verts_per_prim = cube.CreateAttribute("numVertsPerPrim");
verts_per_prim = cube.CreateAttribute("vertsPerPrim");
positions = cube.CreateAttribute("position");
rest_positions = cube.CreateAttribute("restPosition");

positions.Print()
# Create a cube, a cube has 12 faces
tris = SimulationAPI.IntArray();
vert_counts = SimulationAPI.IntArray();
verts = SimulationAPI.Vector3Array();
origin = SimulationAPI.Vector3();

origin.Set(0, 1.0);
origin.Set(1, 1.0);
origin.Set(2, 1.0);

# print(len(origin))
# SimulationAPI.GetVector3Component(origin, 0);
SimulationAPI.Utils.CreateCube(origin, 1, 1.0, 2.0, 3.0, tris, verts)

print (tris)
print (verts)
print (len(tris))
vert_counts = SimulationAPI.IntArray([3] * (int(len(tris) / 3)))
print (vert_counts)

# Write to a USD stage for testing


#

num_verts_per_prim.SetIntArrayValue(vert_counts);
verts_per_prim.SetIntArrayValue(tris);
positions.SetDataArrayType(SimulationAPI.Attribute.DataArrayType.PerVertex);
positions.SetVector3ArrayValue(verts);
rest_positions.SetDataArrayType(SimulationAPI.Attribute.DataArrayType.PerVertex);
rest_positions.SetVector3ArrayValue(verts);

scene.start_time = 0;
scene.end_time = 200;

driver = SimulationAPI.SimulationDriver(scene)

for f in range(int(scene.start_time), int(scene.end_time)):
    driver.SimulateFrame(f, False)
