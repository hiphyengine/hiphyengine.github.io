from ..properties import object_properties

def draw_prop(
        layout,
        prop_owner,
        prop_name,
        prop_label,
        expand=False,
        use_column=False,
        boolean=False,
        prop_search=None,
        active=True,
        draw_label=True
    ):
    row = layout.row(align=True)
    if not active:
        row.active = False
    if draw_label:
        row.label(text=prop_label + ':')
    if use_column:
        value_layout = row.column(align=True)
    else:
        value_layout = row
    if expand:
        value_layout.prop(prop_owner, prop_name, expand=True)
    else:
        if boolean:
            prop_value = getattr(prop_owner, prop_name)
            if prop_value:
                value_layout.prop(prop_owner, prop_name, text='Yes', toggle=True)
            else:
                value_layout.prop(prop_owner, prop_name, text='No', toggle=True)
        elif prop_search:
            value_layout.prop_search(prop_owner, prop_name, bpy.data, prop_search, text='')
        else:
            value_layout.prop(prop_owner, prop_name, text='')
            
def draw_mappable_prop(
        layout,
        prop_owner,
        prop_name,
        prop_label,
        expand=False,
        use_column=False,
        boolean=False,
        prop_search=None,
        active=True,
        draw_label=True
    ):
    row = layout.row(align=True)
    if not active:
        row.active = False
    if draw_label:
        row.label(text=prop_label + ':')
    if use_column:
        value_layout = row.column(align=True)
    else:
        value_layout = row
    use_attribute = getattr(prop_owner, prop_name + "_use_attribute");
    if use_attribute:
        col = row.column(align=True)
        col.prop(prop_owner, prop_name + "_attribute", text='')
        col = row.column(align=True)
        col.prop(prop_owner, prop_name + "_use_attribute", text='')
    else:
        if expand:
            value_layout.prop(prop_owner, prop_name, expand=True)
        else:
            if boolean:
                prop_value = getattr(prop_owner, prop_name)
                if prop_value:
                    value_layout.prop(prop_owner, prop_name, text='Yes', toggle=True)
                else:
                    value_layout.prop(prop_owner, prop_name, text='No', toggle=True)
            elif prop_search:
                value_layout.prop_search(prop_owner, prop_name, bpy.data, prop_search, text='')
            else:
                value_layout.prop(prop_owner, prop_name, text='')
        col = row.column(align=True)
        col.prop(prop_owner, prop_name + "_use_attribute", text='')
    

from ..cAPI import SimulationAPI

def draw_dynamic_props(
        layout,
        prop_owner,
        tag,
        expand=False,
        use_column=False,
        boolean=False,
        prop_search=None,
        active=True,
        ignore_list=None
    ):
    for index, n in object_properties.dynamic_properties:
        if ignore_list and n in ignore_list:
            continue
        p = SimulationAPI.properties[n]
        if ((not p.is_internal) and (p.tag.value & tag.value)):
            if (p.is_mappable):
                draw_mappable_prop(
                    layout,
                    prop_owner,
                    p.name,
                    p.display_name,
                    expand,
                    use_column,
                    boolean,
                    prop_search,
                    active)
            else:
                draw_prop(
                    layout,
                    prop_owner,
                    p.name,
                    p.display_name,
                    expand,
                    use_column,
                    boolean,
                    prop_search,
                    active)
            

def draw_dynamic_props_from_list(
        prop_list,
        layout,
        prop_owner,
        tag,
        expand=False,
        use_column=False,
        boolean=False,
        prop_search=None,
        active=True
    ):
    for n in prop_list:
        p = SimulationAPI.properties[n]
        if ((not p.is_internal) and (p.tag.value & tag.value)):
            if (p.is_mappable):
                draw_mappable_prop(
                    layout,
                    prop_owner,
                    p.name,
                    p.display_name,
                    expand,
                    use_column,
                    boolean,
                    prop_search,
                    active)
            else:
                draw_prop(
                    layout,
                    prop_owner,
                    p.name,
                    p.display_name,
                    expand,
                    use_column,
                    boolean,
                    prop_search,
                    active)
            
