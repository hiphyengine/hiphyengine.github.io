import bpy
from . import utils
from ..cAPI import SimulationAPI

class HI_PHY_PT_ExpressionAttribute(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: Expression Attribute"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout

        utils.draw_prop(lay, hi_phy, 'expression_attribute_live_update', 'Live update', expand=False, use_column=True)

        row = lay.row(align=True)
        row.template_list(
            "HI_PHY_UL_ExpressionAttribute",
            "",                     
            hi_phy, "expression_attribute_list",  # data, property
            hi_phy, "expression_attribute_index",
        )
        col = row.column(align=True)
        op = col.operator("hi_phy.add_item_to_list", icon="ADD", text="")
        op.list_prop = "expression_attribute_list"
        op.index_prop = "expression_attribute_index"
        op = col.operator("hi_phy.remove_item_from_list", icon="REMOVE", text="")
        op.list_prop = "expression_attribute_list"
        op.index_prop = "expression_attribute_index"
        row = lay.row(align=True)
        op = row.column(align=True).operator('hi_phy.evaluate_expressions', text= 'Evaluate Expression Attributes')
        op.object_name = obj.name

