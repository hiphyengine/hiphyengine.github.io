import bpy
from . import utils
from ..cAPI import SimulationAPI

class HI_PHY_PT_MPMMeshlessParticles(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: MPM Meshless Particles"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active and hi_phy.object_type == 'MPM_MESHLESS_PARTICLES'

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout

        # create ui elements
        utils.draw_prop(lay, hi_phy, 'solver', 'Solver', expand=False, use_column=True)
        utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.MPMMeshlessParticlesObject, expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'mpm_material', 'Material', expand=False, use_column=True)

        if (hi_phy.mpm_material == "SNOW"):
            utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.MPMSnow, expand=False, use_column=True)
        if (hi_phy.mpm_material == "SAND"):
            utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.MPMSand, expand=False, use_column=True)

