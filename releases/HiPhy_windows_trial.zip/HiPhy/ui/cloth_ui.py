import bpy
from . import utils
from ..cAPI import SimulationAPI

class HI_PHY_PT_Cloth(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: Cloth"

    elastic_membrane_material_properties = ["clothMu", "clothLambda", "clothBendStiffness", "clothMuDamping", "clothLambdaDamping", "clothBendDamping"]
    uv_panel_material_properties = ["clothStretchStiffnessU", "clothStretchStiffnessV", "clothShearStiffness", "clothBendStiffnessU", "clothBendStiffnessV", "clothStretchDamping", "clothShearDamping", "clothBendDamping"]

    material_properties = elastic_membrane_material_properties + uv_panel_material_properties
    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active and hi_phy.object_type == 'CLOTH'

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout

        # create ui elements
        utils.draw_prop(lay, hi_phy, 'solver', 'Solver', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'rest_shape', 'Rest Shape', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'target_shape', 'Target Shape', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'driven_shape', 'Driven Shape', expand=False, use_column=True)
        lay.separator()
        utils.draw_prop(lay, hi_phy, 'cloth_material', 'Cloth Material', expand=False, use_column=True)
        if (hi_phy.cloth_material == 'ELASTIC_MEMBRANE') :
            utils.draw_dynamic_props_from_list(self.elastic_membrane_material_properties, lay, hi_phy, SimulationAPI.Property.Tag.Cloth, expand=False, use_column=True)
        elif (hi_phy.cloth_material == 'UVPANEL') :
            utils.draw_dynamic_props_from_list(self.uv_panel_material_properties, lay, hi_phy, SimulationAPI.Property.Tag.Cloth, expand=False, use_column=True)
        else:
            ValueError("Unknwn cloth material model");
        lay.separator()

        utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.Cloth, expand=False, use_column=True, ignore_list=self.material_properties)

        split = lay.split(factor=0.75, align=True)
        split.operator('hi_phy.convert_uv', text='Convert UV').obj = obj.name
