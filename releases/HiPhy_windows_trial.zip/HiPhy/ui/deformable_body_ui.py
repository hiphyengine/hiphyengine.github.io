import bpy
from . import utils
from ..cAPI import SimulationAPI

class HI_PHY_PT_DeformableBody(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: Deformable Body"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active and hi_phy.object_type == 'DEFORMABLE_BODY'

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout

        # create ui elements
        utils.draw_prop(lay, hi_phy, 'solver', 'Solver', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'target_shape', 'Target Shape', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'driven_shape', 'Driven Shape', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'mesh_bone', 'Mesh Bone', expand=False, use_column=True)
        utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.DeformableBody, expand=False, use_column=True)

