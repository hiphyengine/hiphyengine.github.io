from . import object_properties

modules = [
    object_properties
]

def register():
    for module in modules:
        module.register()

def unregister():
    for module in modules:
        module.unregister()
