import bpy
from . import solver_ui
from . import affine_body_ui
from . import collider_ui
from . import elastic_rod_ui
from . import cloth_ui
from . import deformable_body_ui
from . import soft_collider_ui
from . import constraint_ui
from . import force_field_ui
from . import expression_attribute_ui
from . import mpm_meshless_particles_ui
from . import utils

class HI_PHY_UL_ObjectList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if item.object:
            split = layout.split(factor=0.50)
            column_left = split.column()
            column_right = split.column()
            column_left.prop(item, "object", text="", emboss=False, icon="OBJECT_DATA")
            column_right.prop(item, "weight", text="weight", emboss=False)
        else:
            layout.prop(item, "object", text="", emboss=True)

class HI_PHY_UL_ExpressionAttribute(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        split = layout.split(factor=0.50)
        column_left = split.column()
        column_right = split.column()
        column_left.prop(item, "expression", text="Expression", emboss=True)
        column_right.prop(item, "attribute", text="Attribute", emboss=True)

class HI_PHY_PT_Type(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: Type"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout

        # create ui elements
        utils.draw_prop(lay, hi_phy, 'object_type', 'Object Type', expand=True, use_column=True)

import bpy.utils.previews
# create a previews collection
icons = bpy.utils.previews.new()
# load an image file from disk
import os
addon_dir = os.path.dirname(__file__)
icons.load("hiphy", os.path.join(addon_dir, "../icons/hiphy-logo-small.png"), 'IMAGE')
icons.load("hiphy-X", os.path.join(addon_dir, "../icons/hiphy-logo-small-close.png"), 'IMAGE')

def add_hi_phy_button(self, context):
    obj = context.object

    column = self.layout.column(align=True)
    split = column.split(factor=0.5)
    column_left = split.column()
    column_right = split.column()

    if obj.hi_phy.is_active:
        column_right.operator(
            "hi_phy.remove",
            text="Hi Phy",
            icon_value=icons["hiphy-X"].icon_id
        )
    else:
        column_right.operator(
            "hi_phy.add",
            text="Hi Phy",
            icon_value=icons["hiphy"].icon_id
        )

__CLASSES__ = [
    HI_PHY_PT_Type,
    HI_PHY_UL_ObjectList,
    HI_PHY_UL_ExpressionAttribute,
    affine_body_ui.HI_PHY_PT_AffineBody,
    elastic_rod_ui.HI_PHY_PT_ElasticRod,
    cloth_ui.HI_PHY_PT_Cloth,
    deformable_body_ui.HI_PHY_PT_DeformableBody,
    soft_collider_ui.HI_PHY_PT_SoftCollider,
    constraint_ui.HI_PHY_PT_Constraint,
    collider_ui.HI_PHY_PT_Collider,
    force_field_ui.HI_PHY_PT_ForceField,
    expression_attribute_ui.HI_PHY_PT_ExpressionAttribute,
    solver_ui.HI_PHY_PT_LagrangianSolver,
    solver_ui.HI_PHY_PT_MPMSolver,
    mpm_meshless_particles_ui.HI_PHY_PT_MPMMeshlessParticles
]

def register():
    bpy.types.PHYSICS_PT_add.append(add_hi_phy_button)
    for class_ in __CLASSES__:
        bpy.utils.register_class(class_)


def unregister():
    for class_ in reversed(__CLASSES__):
        bpy.utils.unregister_class(class_)
    bpy.types.PHYSICS_PT_add.remove(add_hi_phy_button)
