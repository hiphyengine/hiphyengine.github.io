import bpy
from . import utils
from ..cAPI import SimulationAPI

class HI_PHY_PT_ForceField(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: Force Field"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active and hi_phy.object_type == 'FORCE_FIELD'

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout

        utils.draw_prop(lay, hi_phy, 'solver', 'Solver', expand=False, use_column=True)

        # create ui elements
        utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.ForceField, expand=False, use_column=True)

        # List element
        row = lay.row(align=True)
        row.label(text="Applies to:")
        row = lay.row(align=True)
        row.template_list(
            "HI_PHY_UL_ObjectList",
            "",                     
            hi_phy, "force_field_object_list",  # data, property
            hi_phy, "force_field_object_index",
        )
        col = row.column(align=True)
        op = col.operator("hi_phy.add_item_to_list", icon="ADD", text="")
        op.list_prop = "force_field_object_list"
        op.index_prop = "force_field_object_index"
        op = col.operator("hi_phy.remove_item_from_list", icon="REMOVE", text="")
        op.list_prop = "force_field_object_list"
        op.index_prop = "force_field_object_index"

        row = lay.row(align=True)
        utils.draw_prop(row.column(align=True), hi_phy, 'force_field_visualization_x_min', 'Visualization Range X')
        utils.draw_prop(row.column(align=True), hi_phy, 'force_field_visualization_x_max', '', draw_label = False)

        row = lay.row(align=True)
        utils.draw_prop(row.column(align=True), hi_phy, 'force_field_visualization_y_min', 'Visualization Range Y')
        utils.draw_prop(row.column(align=True), hi_phy, 'force_field_visualization_y_max', '', draw_label = False)

        row = lay.row(align=True)
        utils.draw_prop(row.column(align=True), hi_phy, 'force_field_visualization_z_min', 'Visualization Range Z')
        utils.draw_prop(row.column(align=True), hi_phy, 'force_field_visualization_z_max', '', draw_label = False)

        utils.draw_prop(lay, hi_phy, 'force_field_visualization_x_slice', 'Visualization X Slice')

        utils.draw_prop(lay, hi_phy, 'force_field_visualization_y_slice', 'Visualization Z Slice')
        
        utils.draw_prop(lay, hi_phy, 'force_field_visualization_z_slice', 'Visualization Z Slice')

        utils.draw_prop(lay, hi_phy, 'force_field_visualization_scale', 'Visualization Scale')

        utils.draw_prop(lay, hi_phy, 'force_field_visualization_live_update', 'Live Update')

        row = lay.row(align=True)
        row.column(align=True).operator('hi_phy.create_force_field_visualization_mesh', text='Update Visualization Mesh').obj = obj.name
