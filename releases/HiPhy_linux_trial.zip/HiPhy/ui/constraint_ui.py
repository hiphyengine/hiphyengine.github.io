import bpy
from . import utils
from ..cAPI import SimulationAPI

class HI_PHY_PT_Constraint(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: Constraint"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active and hi_phy.object_type == 'CONSTRAINT'

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout

        if (hi_phy.constraint_type == SimulationAPI.ConstraintType.BindingConstraint):
            utils.draw_prop(lay, hi_phy, 'constraint_live_update', 'Live Update', expand=False, use_column=True)
        if (hi_phy.constraint_type != SimulationAPI.ConstraintType.BindingConstraint and hi_phy.constraint_type != SimulationAPI.ConstraintType.RootConstraint):
            utils.draw_prop(lay, hi_phy, 'constraintIsSoft', 'Is Soft', expand=False, use_column=True)

        utils.draw_prop(lay, hi_phy, 'constraintEnabled', 'Is Enabled', expand=False, use_column=True)
        # Root constraint doesn't have any parameter besides enabled
        if (hi_phy.constraint_type != SimulationAPI.ConstraintType.RootConstraint):
            utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.Constraint, expand=False, use_column=True, ignore_list=["constraintIsSoft", "constraintEnabled"])
