import bpy
from . import utils
from ..utils import caches
from ..cAPI import SimulationAPI

class HI_PHY_PT_LagrangianSolver(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: Lagrangian Solver"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active and hi_phy.object_type == 'LAGRANGIAN_SOLVER'

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout
        utils.draw_prop(lay, hi_phy, 'in_memeory', 'Simulate In Memory')
        utils.draw_prop(lay, hi_phy, 'cache_file', 'Cache File')
        row = lay.row(align=True)
        op = row.column(align=True).operator('hi_phy.save_cache', text='Save Cache')
        op.file_name = hi_phy.cache_file
        op.solver_name = obj.name
        op = row.column(align=True).operator('hi_phy.load_cache', text='Load Cache')
        op.file_name = hi_phy.cache_file
        op.solver_name = obj.name
        utils.draw_prop(lay, hi_phy, 'frame_range_simulation_start', 'Frame Start')
        utils.draw_prop(lay, hi_phy, 'frame_range_simulation_end', 'Frame End')
        utils.draw_prop(lay, hi_phy, 'deformable_body_material', 'Deformable Body Material', expand=False, use_column=True)
        utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.LagrangianSolver, expand=False, use_column=True)
        if (SimulationAPI.GetLicenseTier() == 0):
            row = lay.row(align=True)
            days_left = SimulationAPI.GetLicenseDaysLeft()
            row.label(text="This is a trial version of HiPhyEngine. " + str(days_left) + " day(s) left for the trial period.");
        row = lay.row(align=True)
        row.column(align=True).operator('hi_phy.run_sim', text='Run Sim').active_solver = obj.name
        row.column(align=True).operator('hi_phy.stop_sim', text='Stop Sim').active_solver = obj.name
        row.column(align=True).operator('hi_phy.resume_sim', text='Resume Sim (From Current Frame)').active_solver = obj.name
        row = lay.row(align=True)
        row.column(align=True).operator('hi_phy.clear_cache', text='Clear Cache').solver_name = obj.name
        row = lay.row(align=True)
        if obj.name in caches:
            [finished_frames, total_frames] = caches[obj.name].GetProgress()
            row.progress(text='Progress: ' + str(finished_frames) + "/" + str(total_frames), factor = finished_frames / total_frames if total_frames > 0 else 0)
        row = lay.row(align=True)
        row.column(align=True).operator('hi_phy.preload_curves', text='Preload Curves').active_solver = obj.name

class HI_PHY_PT_MPMSolver(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: MPM Solver"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active and hi_phy.object_type == 'MPM_SOLVER'

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout
        utils.draw_prop(lay, hi_phy, 'cache_file', 'Cache File')
        row = lay.row(align=True)
        op = row.column(align=True).operator('hi_phy.save_cache', text='Save Cache')
        op.file_name = hi_phy.cache_file
        op.solver_name = obj.name
        op = row.column(align=True).operator('hi_phy.load_cache', text='Load Cache')
        op.file_name = hi_phy.cache_file
        op.solver_name = obj.name
        utils.draw_prop(lay, hi_phy, 'frame_range_simulation_start', 'Frame Start')
        utils.draw_prop(lay, hi_phy, 'frame_range_simulation_end', 'Frame End')
        utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.MPMSolver, expand=False, use_column=True)
        row = lay.row(align=True)
        row.column(align=True).operator('hi_phy.run_mpm_sim', text='Run Sim').active_solver = obj.name
        row.column(align=True).operator('hi_phy.stop_sim', text='Stop Sim').active_solver = obj.name
