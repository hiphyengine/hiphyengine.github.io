import bpy
from . import utils
from ..cAPI import SimulationAPI

class HI_PHY_PT_ElasticRod(bpy.types.Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_label = "Hi Phy: Elastic Rod"

    @classmethod
    def poll(cls, context):
        hi_phy = context.object.hi_phy
        return hi_phy.is_active and hi_phy.object_type == 'ELASTIC_ROD'

    def draw(self, context):
        obj = context.object
        hi_phy = obj.hi_phy
        lay = self.layout

        # create ui elements
        row = lay.row(align=True)
        row.operator('hi_phy.add_parameterization_attribute', text='Add parameterization attribute to curve').curves = obj.name
        row = lay.row(align=True)
        row.operator('hi_phy.add_base_normal', text='Add base normal to curve').simulation_curves = obj.name
        utils.draw_prop(lay, hi_phy, 'solver', 'Solver', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'rest_shape', 'Rest Shape', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'target_shape', 'Target Shape', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'preload_reference_shape', 'Preload Reference Shape', expand=False, use_column=True)
        utils.draw_prop(lay, hi_phy, 'driven_shape', 'Driven Shape', expand=False, use_column=True)
        utils.draw_dynamic_props(lay, hi_phy, SimulationAPI.Property.Tag.ElasticRod, expand=False, use_column=True)
