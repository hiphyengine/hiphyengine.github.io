import bpy
import numpy as np
from ..cAPI import SimulationAPI

def ComputeVisualizationPoints(hi_phy, p, f):
    force_field_evaluator = SimulationAPI.ForceField(hi_phy.ForceFieldExpression, SimulationAPI.ExpressionType.SeExpr)
    if not force_field_evaluator.IsValid():
        return None
    time = bpy.context.scene.frame_current
    solver = hi_phy.solver
    if (solver and solver.hi_phy.is_active):
        time = time * solver.hi_phy.timeScale / solver.hi_phy.framerate
    else:
        time = time / bpy.context.scene.render.fps
    if (p.shape != f.shape):
        return None

    force_field_evaluator.Evaluate(p, f, time, p.shape[0])
    scale =  hi_phy.force_field_visualization_scale
    # compute the end points
    return np.concatenate((p, (p + (f * scale))))
