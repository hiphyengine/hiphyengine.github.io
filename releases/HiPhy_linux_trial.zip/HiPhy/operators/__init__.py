from . import operators
from . import operator_add_base_normal
from . import operator_add_parameterization_attribute
from . import operator_run_sim
from . import operator_convert_uv
from . import operator_create_point_constraint
from . import operator_create_mesh_constraint
from . import operator_create_root_constraint
from . import operator_create_binding_constraint
from . import operator_create_joint_constraint
from . import operator_convert_particles_to_point_cloud
from . import operator_cache_io
from . import operator_force_field
from . import operator_evaluate_expressions

modules = [
    operators,
    operator_add_base_normal,
    operator_add_parameterization_attribute,
    operator_run_sim,
    operator_convert_uv,
    operator_create_point_constraint,
    operator_create_mesh_constraint,
    operator_create_root_constraint,
    operator_create_binding_constraint,
    operator_create_joint_constraint,
    operator_convert_particles_to_point_cloud,
    operator_cache_io,
    operator_force_field,
    operator_evaluate_expressions
]

def register():
    for module in modules:
        module.register()

def unregister():
    for module in modules:
        module.unregister()
