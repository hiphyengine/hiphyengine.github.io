from ..utils import create_curve_parameterization_attribute
import bpy

class HI_PHY_OT_ParameterizationAttribute(bpy.types.Operator):
    bl_idname = "hi_phy.add_parameterization_attribute"
    bl_label = "Hi Phy Add Parameterization Attribute"
    bl_options = {'REGISTER', 'UNDO_GROUPED'}

    curves: bpy.props.StringProperty(name="Curves")

    def execute(self, context):
        obj = bpy.data.objects[self.curves]
        if (not create_curve_parameterization_attribute.create(obj, self)):
            return {'CANCELLED'}
        return {'FINISHED'}

__CLASSES__ = [
    HI_PHY_OT_ParameterizationAttribute
]

def register():
    for class_ in __CLASSES__:
        bpy.utils.register_class(class_)


def unregister():
    for class_ in reversed(__CLASSES__):
        bpy.utils.unregister_class(class_)
