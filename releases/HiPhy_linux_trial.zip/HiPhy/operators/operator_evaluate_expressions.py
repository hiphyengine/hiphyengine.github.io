from ..utils import evaluate_expression_attributes
import bpy

class HI_PHY_OT_ParameterizationAttribute(bpy.types.Operator):
    bl_idname = "hi_phy.evaluate_expressions"
    bl_label = "Hi Phy Evaluate Expression Attributes"
    bl_options = {'REGISTER', 'UNDO_GROUPED'}

    object_name: bpy.props.StringProperty(name="object")

    def execute(self, context):
        obj = bpy.data.objects[self.object_name]
        if (not evaluate_expression_attributes.evaluate_expressions(obj, self)):
            return {'CANCELLED'}
        return {'FINISHED'}

__CLASSES__ = [
    HI_PHY_OT_ParameterizationAttribute
]

def register():
    for class_ in __CLASSES__:
        bpy.utils.register_class(class_)


def unregister():
    for class_ in reversed(__CLASSES__):
        bpy.utils.unregister_class(class_)
