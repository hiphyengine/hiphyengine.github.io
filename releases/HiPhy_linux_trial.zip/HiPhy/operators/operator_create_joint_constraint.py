import bpy
import bmesh
import os
from ..cAPI import SimulationAPI
from .. import utils
from ..utils import create_joint_constraint
import numpy as np

class HI_PHY_OT_CreateJointConstraint(bpy.types.Operator):
    bl_idname = "hi_phy.create_joint_constraint"
    bl_label = "Hi Phy Create Joint Constraint"
    bl_options = {'REGISTER'}

    binding_simulation_object_1: bpy.props.StringProperty(name="Affine Body 1")
    binding_simulation_object_2: bpy.props.StringProperty(name="Affine Body 2")
    joint_location: bpy.props.FloatVectorProperty(name="Joint Location")
    binding_option: bpy.props.EnumProperty(
        name="Binding Option",
        items=[
            ('OP_JointTwoBodies', "Create a Joint Between Two Affine Bodies", "Create a Joint Between Two Affine Bodies"),
            ('OP_JointOneBody', "Create a Joint On A Single Affine Body", "Create a Joint On A Single Affine Body"),
        ],
        default='OP_JointOneBody'
    )

    def invoke(self, context, event):
        for obj in bpy.context.selected_objects:
            if utils.isSimulationObject(obj) and self.binding_simulation_object_1 == "":
                self.binding_simulation_object_1 = obj.name
            elif utils.isSimulationObject(obj):
                self.binding_simulation_object_2 = obj.name
        self.joint_location = bpy.context.scene.cursor.location
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "binding_option")
        layout.prop(self, "binding_simulation_object_1")
        if (self.binding_option == 'OP_JointTwoBodies') :
            layout.prop(self, "binding_simulation_object_2")
        layout.prop(self, "joint_location")

    def execute(self, context):
        depsgraph = bpy.context.evaluated_depsgraph_get()
        # evaluate it so we can get the correct topology after modifiers
        sim_obj_1 = bpy.data.objects[self.binding_simulation_object_1].evaluated_get(depsgraph)
        name = "self.binding_simulation_object_1"
        sim_obj_2 = None
        if self.binding_simulation_object_2 != "":
            sim_obj_2 = bpy.data.objects[self.binding_simulation_object_2].evaluated_get(depsgraph)
            name += "_" + self.binding_simulation_object_2;
        # we can't get position attributes from mesh unless we are in object mode
        bk_mode = bpy.context.object.mode
        bpy.ops.object.mode_set(mode='OBJECT')
        create_joint_constraint.createJointConstraint(sim_obj_1, sim_obj_2, self.joint_location, name + "_joint_constraint", self);
        bpy.ops.object.mode_set(mode=bk_mode)
        return {'FINISHED'}

__CLASSES__ = [
    HI_PHY_OT_CreateJointConstraint
]

# Define the menu draw function
def menu_draw(self, context):
    # TODO: only add to the menu if the edited object is a valid simulation object
    layout = self.layout
    layout.operator_context = 'INVOKE_DEFAULT'
    layout.operator("hi_phy.create_joint_constraint")

def register():
    for class_ in __CLASSES__:
        bpy.utils.register_class(class_)
        bpy.types.VIEW3D_MT_object_context_menu.append(menu_draw)


def unregister():
    for class_ in reversed(__CLASSES__):
        bpy.types.VIEW3D_MT_object_context_menu.remove(menu_draw)
        bpy.utils.unregister_class(class_)
